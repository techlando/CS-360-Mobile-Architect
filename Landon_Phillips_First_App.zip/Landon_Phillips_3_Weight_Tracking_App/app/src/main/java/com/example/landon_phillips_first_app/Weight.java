package com.example.landon_phillips_first_app;

public class Weight {
    public int id;
    public double weight;
    public String date;

    public Weight(int id, double weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }
}
